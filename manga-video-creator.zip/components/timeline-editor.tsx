'use client'

import { useState, useCallback } from 'react'
import { Plus, Trash2, Volume2 } from 'lucide-react'
import { VoiceGenerator } from './voice-generator'
import toast from 'react-hot-toast'

export interface TimelineScene {
  id: string
  index: number
  duration: number
  voice?: {
    audioUrl: string
    duration: number
    text: string
  }
}

interface TimelineEditorProps {
  videoId: string
  scenes: TimelineScene[]
  onScenesChange: (scenes: TimelineScene[]) => void
}

export function TimelineEditor({ videoId, scenes, onScenesChange }: TimelineEditorProps) {
  const [selectedSceneId, setSelectedSceneId] = useState<string | null>(null)
  const [showVoiceGenerator, setShowVoiceGenerator] = useState(false)

  const addScene = useCallback(() => {
    const newScene: TimelineScene = {
      id: Math.random().toString(36).substr(2, 9),
      index: scenes.length,
      duration: 3,
    }
    const updated = [...scenes, newScene]
    onScenesChange(updated)
    setSelectedSceneId(newScene.id)
    toast.success('Scene added')
  }, [scenes, onScenesChange])

  const deleteScene = useCallback(
    (sceneId: string) => {
      const filtered = scenes.filter((s) => s.id !== sceneId)
      const reindexed = filtered.map((s, i) => ({ ...s, index: i }))
      onScenesChange(reindexed)
      if (selectedSceneId === sceneId) {
        setSelectedSceneId(reindexed[0]?.id || null)
      }
      toast.success('Scene removed')
    },
    [scenes, selectedSceneId, onScenesChange]
  )

  const updateSceneDuration = useCallback(
    (sceneId: string, duration: number) => {
      const updated = scenes.map((s) => (s.id === sceneId ? { ...s, duration: Math.max(1, duration) } : s))
      onScenesChange(updated)
    },
    [scenes, onScenesChange]
  )

  const handleVoiceGenerated = useCallback(
    (audioUrl: string, duration: number) => {
      const updated = scenes.map((s) => {
        if (s.id === selectedSceneId) {
          return {
            ...s,
            voice: {
              audioUrl,
              duration,
              text: '', // Would be set by voice generator
            },
          }
        }
        return s
      })
      onScenesChange(updated)
      setShowVoiceGenerator(false)
    },
    [scenes, selectedSceneId, onScenesChange]
  )

  const selectedScene = scenes.find((s) => s.id === selectedSceneId)
  const totalDuration = scenes.reduce((sum, s) => sum + s.duration, 0)

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Timeline List */}
      <div className="lg:col-span-2 bg-slate-800 rounded-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-white">Timeline Scenes</h3>
          <button
            onClick={addScene}
            className="flex items-center gap-2 bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg transition text-sm"
          >
            <Plus size={18} />
            Add Scene
          </button>
        </div>

        {scenes.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-slate-400 mb-4">No scenes yet</p>
            <button
              onClick={addScene}
              className="bg-purple-600 hover:bg-purple-700 text-white px-6 py-2 rounded-lg transition"
            >
              Create First Scene
            </button>
          </div>
        ) : (
          <div className="space-y-2 max-h-96 overflow-y-auto">
            {scenes.map((scene, idx) => (
              <div
                key={scene.id}
                onClick={() => setSelectedSceneId(scene.id)}
                className={`p-4 rounded-lg cursor-pointer transition group ${
                  selectedSceneId === scene.id ? 'bg-purple-600' : 'bg-slate-700 hover:bg-slate-600'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex-1">
                    <p className="font-semibold text-white">Scene {idx + 1}</p>
                    {scene.voice && (
                      <div className="flex items-center gap-2 mt-1">
                        <Volume2 size={14} className="text-purple-400" />
                        <span className="text-xs text-slate-300">Voice: {scene.voice.duration}s</span>
                      </div>
                    )}
                  </div>
                  <button
                    onClick={(e) => {
                      e.stopPropagation()
                      deleteScene(scene.id)
                    }}
                    className="p-2 opacity-0 group-hover:opacity-100 bg-red-600 hover:bg-red-700 text-white rounded transition"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="range"
                    min="1"
                    max="10"
                    value={scene.duration}
                    onChange={(e) => {
                      e.stopPropagation()
                      updateSceneDuration(scene.id, parseInt(e.target.value))
                    }}
                    className="flex-1 h-2 bg-slate-600 rounded-lg cursor-pointer"
                  />
                  <span className="text-sm text-slate-300 min-w-12">{scene.duration}s</span>
                </div>
              </div>
            ))}
          </div>
        )}

        {scenes.length > 0 && (
          <div className="mt-4 p-4 bg-slate-700 rounded-lg">
            <p className="text-slate-300 text-sm">
              Total Duration: <span className="font-semibold">{totalDuration}s</span>
            </p>
          </div>
        )}
      </div>

      {/* Scene Details Panel */}
      <div className="space-y-4">
        {selectedScene ? (
          <>
            <div className="bg-slate-800 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-white mb-4">Scene Details</h3>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">Scene Number</label>
                  <p className="text-white bg-slate-700 px-4 py-2 rounded-lg">Scene {selectedScene.index + 1}</p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">Duration (seconds)</label>
                  <input
                    type="number"
                    min="1"
                    max="10"
                    value={selectedScene.duration}
                    onChange={(e) => updateSceneDuration(selectedScene.id, parseInt(e.target.value))}
                    className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:border-purple-500"
                  />
                </div>

                {selectedScene.voice ? (
                  <div className="bg-purple-600/20 border border-purple-500 rounded-lg p-4">
                    <p className="text-sm font-semibold text-purple-300 mb-2">Voice Added</p>
                    <p className="text-xs text-slate-300">Duration: {selectedScene.voice.duration}s</p>
                    <button
                      onClick={() => setShowVoiceGenerator(true)}
                      className="mt-3 w-full text-sm bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg transition"
                    >
                      Replace Voice
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => setShowVoiceGenerator(true)}
                    className="w-full flex items-center justify-center gap-2 bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg transition"
                  >
                    <Volume2 size={18} />
                    Add Voice
                  </button>
                )}
              </div>
            </div>

            {showVoiceGenerator && (
              <VoiceGenerator
                videoId={videoId}
                sceneIndex={selectedScene.index}
                onVoiceGenerated={handleVoiceGenerated}
              />
            )}
          </>
        ) : (
          <div className="bg-slate-800 rounded-lg p-6 text-center text-slate-400">
            <p>Select a scene to edit details</p>
          </div>
        )}
      </div>
    </div>
  )
}
