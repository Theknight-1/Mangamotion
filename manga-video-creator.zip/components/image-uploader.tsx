'use client'

import { useState, useRef } from 'react'
import { Upload, X } from 'lucide-react'
import toast from 'react-hot-toast'

interface ImageUploaderProps {
  onImageSelect: (url: string, file: File) => void
  disabled?: boolean
}

export function ImageUploader({ onImageSelect, disabled }: ImageUploaderProps) {
  const [uploading, setUploading] = useState(false)
  const [preview, setPreview] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const dragRef = useRef<HTMLDivElement>(null)

  async function handleFile(file: File) {
    if (!file.type.startsWith('image/')) {
      toast.error('Please select an image file')
      return
    }

    setUploading(true)
    try {
      // Create preview
      const reader = new FileReader()
      reader.onload = (e) => {
        setPreview(e.target?.result as string)
      }
      reader.readAsDataURL(file)

      // Upload file
      const formData = new FormData()
      formData.append('file', file)

      const response = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      })

      if (!response.ok) {
        throw new Error('Upload failed')
      }

      const data = await response.json()
      onImageSelect(data.url, file)
      toast.success('Image uploaded successfully!')
    } catch (error) {
      console.error('[v0] Upload error:', error)
      toast.error('Failed to upload image')
      setPreview(null)
    } finally {
      setUploading(false)
    }
  }

  function handleDrop(e: React.DragEvent) {
    e.preventDefault()
    e.stopPropagation()
    if (!disabled && !uploading) {
      const file = e.dataTransfer.files[0]
      if (file) handleFile(file)
    }
  }

  function handleChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.currentTarget.files?.[0]
    if (file) handleFile(file)
  }

  function clearPreview() {
    setPreview(null)
    if (fileInputRef.current) {
      fileInputRef.current.value = ''
    }
  }

  if (preview) {
    return (
      <div className="relative rounded-lg overflow-hidden bg-slate-700 aspect-video w-full">
        <img src={preview} alt="Preview" className="w-full h-full object-cover" />
        <button
          onClick={clearPreview}
          disabled={uploading}
          className="absolute top-2 right-2 p-2 bg-red-600 hover:bg-red-700 rounded-full text-white disabled:opacity-50"
        >
          <X size={20} />
        </button>
      </div>
    )
  }

  return (
    <div
      ref={dragRef}
      onDragOver={(e) => {
        e.preventDefault()
        e.stopPropagation()
      }}
      onDrop={handleDrop}
      onClick={() => !disabled && !uploading && fileInputRef.current?.click()}
      className={`relative border-2 border-dashed border-slate-600 rounded-lg p-12 text-center cursor-pointer transition ${
        uploading || disabled
          ? 'opacity-50 cursor-not-allowed'
          : 'hover:border-purple-500 hover:bg-slate-700/50'
      }`}
    >
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleChange}
        disabled={disabled || uploading}
        className="hidden"
      />

      <Upload className="mx-auto mb-4 text-slate-400" size={40} />
      <p className="text-slate-200 font-semibold mb-2">
        {uploading ? 'Uploading...' : 'Drop your image here or click to select'}
      </p>
      <p className="text-slate-400 text-sm">Supports JPG, PNG, and WebP images</p>
    </div>
  )
}
