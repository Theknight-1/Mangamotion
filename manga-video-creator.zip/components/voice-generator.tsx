'use client'

import { useState, useEffect } from 'react'
import { Mic, Volume2 } from 'lucide-react'
import toast from 'react-hot-toast'

interface VoiceGeneratorProps {
  videoId: string
  sceneIndex: number
  onVoiceGenerated: (audioUrl: string, duration: number) => void
}

interface VoiceProfile {
  id: string
  name: string
  voiceId: string
  language: string
  speed: number
  pitch: number
}

export function VoiceGenerator({ videoId, sceneIndex, onVoiceGenerated }: VoiceGeneratorProps) {
  const [text, setText] = useState('')
  const [voiceProfiles, setVoiceProfiles] = useState<VoiceProfile[]>([])
  const [selectedVoice, setSelectedVoice] = useState('')
  const [speed, setSpeed] = useState(1)
  const [pitch, setPitch] = useState(0)
  const [generating, setGenerating] = useState(false)

  useEffect(() => {
    fetchVoiceProfiles()
  }, [])

  async function fetchVoiceProfiles() {
    try {
      const response = await fetch('/api/voice-profiles')
      if (response.ok) {
        const data = await response.json()
        setVoiceProfiles(data.profiles)
        if (data.profiles.length > 0) {
          setSelectedVoice(data.profiles[0].voiceId)
        }
      }
    } catch (error) {
      console.error('[v0] Fetch voice profiles error:', error)
    }
  }

  async function generateVoice() {
    if (!text.trim()) {
      toast.error('Please enter text to generate voice')
      return
    }

    if (!selectedVoice) {
      toast.error('Please select a voice')
      return
    }

    setGenerating(true)
    try {
      const response = await fetch('/api/generate-voice', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          videoId,
          text,
          voiceId: selectedVoice,
          sceneIndex,
          speed,
          pitch,
        }),
      })

      if (!response.ok) throw new Error('Voice generation failed')

      const data = await response.json()
      onVoiceGenerated(data.voice.audioUrl, data.voice.duration)
      toast.success('Voice generated successfully!')
      setText('')
    } catch (error) {
      console.error('[v0] Voice generation error:', error)
      toast.error('Failed to generate voice')
    } finally {
      setGenerating(false)
    }
  }

  return (
    <div className="bg-slate-800 rounded-lg p-6 space-y-4">
      <h3 className="text-lg font-semibold text-white flex items-center gap-2">
        <Mic size={20} />
        Generate Voice
      </h3>

      <div>
        <label className="block text-sm font-medium text-slate-300 mb-2">Text to Speak</label>
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          disabled={generating}
          className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-purple-500 transition disabled:opacity-50"
          placeholder="Enter the text you want to convert to speech..."
          rows={4}
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-slate-300 mb-2">Voice</label>
          <select
            value={selectedVoice}
            onChange={(e) => setSelectedVoice(e.target.value)}
            disabled={generating}
            className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:border-purple-500 transition disabled:opacity-50"
          >
            <option value="">Select a voice</option>
            {voiceProfiles.map((profile) => (
              <option key={profile.id} value={profile.voiceId}>
                {profile.name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-300 mb-2">Speed</label>
          <input
            type="range"
            min="0.5"
            max="2"
            step="0.1"
            value={speed}
            onChange={(e) => setSpeed(parseFloat(e.target.value))}
            disabled={generating}
            className="w-full h-8 bg-slate-700 rounded-lg cursor-pointer disabled:opacity-50"
          />
          <p className="text-xs text-slate-400 mt-1">{speed.toFixed(1)}x</p>
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-slate-300 mb-2">Pitch</label>
        <input
          type="range"
          min="-12"
          max="12"
          step="1"
          value={pitch}
          onChange={(e) => setPitch(parseInt(e.target.value))}
          disabled={generating}
          className="w-full h-8 bg-slate-700 rounded-lg cursor-pointer disabled:opacity-50"
        />
        <p className="text-xs text-slate-400 mt-1">{pitch > 0 ? '+' : ''}{pitch}</p>
      </div>

      <button
        onClick={generateVoice}
        disabled={generating || !text.trim()}
        className="w-full flex items-center justify-center gap-2 bg-purple-600 hover:bg-purple-700 text-white font-semibold py-2 rounded-lg transition disabled:opacity-50 disabled:cursor-not-allowed"
      >
        <Volume2 size={20} />
        {generating ? 'Generating...' : 'Generate Voice'}
      </button>
    </div>
  )
}
