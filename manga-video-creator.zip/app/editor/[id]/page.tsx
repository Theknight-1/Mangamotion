'use client'

import { useEffect, useState } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { useSession } from '@/lib/auth-client'
import { TimelineScene, TimelineEditor } from '@/components/timeline-editor'
import { VideoExport } from '@/components/video-export'
import { ArrowLeft } from 'lucide-react'
import toast from 'react-hot-toast'

interface Video {
  id: string
  projectId: string
  userId: string
  title: string
  sourceImage: string
  status: string
  timeline: TimelineScene[]
  videoUrl?: string
  duration?: number
}

export default function EditorPage() {
  const params = useParams()
  const router = useRouter()
  const { data: session } = useSession()

  const videoId = params.id as string
  const [video, setVideo] = useState<Video | null>(null)
  const [loading, setLoading] = useState(true)
  const [title, setTitle] = useState('')

  useEffect(() => {
    if (!session) {
      router.push('/login')
      return
    }

    fetchVideo()
  }, [session, videoId, router])

  async function fetchVideo() {
    try {
      const response = await fetch(`/api/videos/${videoId}`)
      if (!response.ok) throw new Error('Video not found')

      const data = await response.json()
      setVideo(data.video)
      setTitle(data.video.title)
    } catch (error) {
      console.error('[v0] Fetch video error:', error)
      toast.error('Failed to load video')
      router.push('/dashboard')
    } finally {
      setLoading(false)
    }
  }

  async function updateVideo(updates: Partial<Video>) {
    if (!video) return

    try {
      const response = await fetch(`/api/videos/${videoId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates),
      })

      if (!response.ok) throw new Error('Update failed')

      const data = await response.json()
      setVideo(data.video)
      toast.success('Changes saved')
    } catch (error) {
      console.error('[v0] Update error:', error)
      toast.error('Failed to save changes')
    }
  }

  async function updateTitle() {
    if (title === video?.title) return
    await updateVideo({ title })
  }

  if (!session) return null
  if (loading) return <div className="flex items-center justify-center h-screen text-white">Loading...</div>
  if (!video) return <div className="flex items-center justify-center h-screen text-white">Video not found</div>

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <div className="bg-slate-800 border-b border-slate-700 p-6 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto flex items-center gap-4">
          <button
            onClick={() => router.push('/dashboard')}
            className="p-2 hover:bg-slate-700 rounded-lg transition text-slate-400 hover:text-white"
          >
            <ArrowLeft size={24} />
          </button>

          <div className="flex-1">
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              onBlur={updateTitle}
              className="text-2xl font-bold text-white bg-transparent border-b border-transparent hover:border-slate-600 focus:border-purple-500 focus:outline-none transition pb-1"
            />
          </div>

          <div className="text-sm text-slate-400">
            <p>Status: <span className="capitalize font-semibold text-slate-300">{video.status}</span></p>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto p-6 space-y-6">
        {/* Video Preview & Export */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <div className="rounded-lg overflow-hidden bg-slate-700 aspect-video w-full">
              <img src={video.sourceImage} alt={video.title} className="w-full h-full object-cover" />
            </div>
          </div>

          <VideoExport videoId={videoId} scenes={video.timeline || []} />
        </div>

        {/* Timeline Editor */}
        <TimelineEditor
          videoId={videoId}
          scenes={video.timeline || []}
          onScenesChange={(scenes) => updateVideo({ timeline: scenes })}
        />
      </div>
    </div>
  )
}
