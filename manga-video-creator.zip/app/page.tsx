'use client'

import { useRouter } from 'next/navigation'
import { useSession } from '@/lib/auth-client'
import { Play, Zap } from 'lucide-react'
import { useEffect } from 'react'

export default function Page() {
  const router = useRouter()
  const { data: session } = useSession()

  useEffect(() => {
    if (session) {
      router.push('/dashboard')
    }
  }, [session, router])

  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Navigation */}
      <nav className="flex items-center justify-between px-6 py-4 max-w-7xl mx-auto">
        <h1 className="text-2xl font-bold text-white">MangaMotion AI</h1>
        <div className="flex gap-4">
          <a
            href="/login"
            className="px-6 py-2 text-white hover:text-purple-400 transition"
          >
            Sign In
          </a>
          <a
            href="/signup"
            className="px-6 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition"
          >
            Get Started
          </a>
        </div>
      </nav>

      {/* Hero */}
      <div className="max-w-7xl mx-auto px-6 py-20 text-center space-y-8">
        <div className="space-y-4">
          <h2 className="text-5xl md:text-6xl font-bold text-white text-balance">
            Transform Manga Images into Animated Videos with AI
          </h2>
          <p className="text-xl text-slate-400 text-balance max-w-2xl mx-auto">
            Upload your manga panels, add voice narration, and create stunning animated videos powered by artificial intelligence.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <a
            href="/signup"
            className="px-8 py-3 bg-purple-600 hover:bg-purple-700 text-white font-semibold rounded-lg transition inline-flex items-center justify-center gap-2"
          >
            <Play size={20} />
            Start Creating Free
          </a>
          <a
            href="#features"
            className="px-8 py-3 bg-slate-700 hover:bg-slate-600 text-white font-semibold rounded-lg transition"
          >
            Learn More
          </a>
        </div>
      </div>

      {/* Features */}
      <div id="features" className="max-w-7xl mx-auto px-6 py-20">
        <h3 className="text-3xl font-bold text-white text-center mb-12">How It Works</h3>
        
        <div className="grid md:grid-cols-3 gap-8">
          <div className="bg-slate-800 rounded-lg p-8 space-y-4">
            <div className="w-12 h-12 bg-purple-600 rounded-lg flex items-center justify-center">
              <Upload size={24} className="text-white" />
            </div>
            <h4 className="text-xl font-semibold text-white">Upload Manga Image</h4>
            <p className="text-slate-400">
              Select your manga panels and upload them to our platform in seconds.
            </p>
          </div>

          <div className="bg-slate-800 rounded-lg p-8 space-y-4">
            <div className="w-12 h-12 bg-purple-600 rounded-lg flex items-center justify-center">
              <Zap size={24} className="text-white" />
            </div>
            <h4 className="text-xl font-semibold text-white">AI Voice Generation</h4>
            <p className="text-slate-400">
              Generate natural-sounding voice narration with our CVoice AI integration.
            </p>
          </div>

          <div className="bg-slate-800 rounded-lg p-8 space-y-4">
            <div className="w-12 h-12 bg-purple-600 rounded-lg flex items-center justify-center">
              <Play size={24} className="text-white" />
            </div>
            <h4 className="text-xl font-semibold text-white">Export & Share</h4>
            <p className="text-slate-400">
              Render high-quality videos and download them for sharing on social media.
            </p>
          </div>
        </div>
      </div>

      {/* Pricing CTA */}
      <div className="max-w-4xl mx-auto px-6 py-20 text-center space-y-8">
        <h3 className="text-3xl font-bold text-white">Choose Your Plan</h3>
        <p className="text-lg text-slate-400">
          Start free and upgrade as your creative needs grow
        </p>
        
        <a
          href="/signup"
          className="inline-block px-8 py-3 bg-purple-600 hover:bg-purple-700 text-white font-semibold rounded-lg transition"
        >
          Create Your First Video Free
        </a>
      </div>

      {/* Footer */}
      <div className="border-t border-slate-700 mt-20 py-8 px-6">
        <div className="max-w-7xl mx-auto text-center text-slate-400">
          <p>&copy; 2026 MangaMotion AI. All rights reserved.</p>
        </div>
      </div>
    </main>
  )
}

function Upload(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
      <polyline points="17 8 12 3 7 8" />
      <line x1="12" y1="3" x2="12" y2="15" />
    </svg>
  )
}
