'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { useSession, signOut } from '@/lib/auth-client'
import { ImageUploader } from '@/components/image-uploader'
import { Plus, LogOut, Settings, Play, Trash2 } from 'lucide-react'
import toast from 'react-hot-toast'

interface Project {
  id: string
  userId: string
  title: string
  description?: string
  coverImage?: string
  createdAt: string
}

interface Video {
  id: string
  projectId: string
  userId: string
  title: string
  sourceImage: string
  status: string
  createdAt: string
}

export default function DashboardPage() {
  const router = useRouter()
  const { data: session } = useSession()

  const [projects, setProjects] = useState<Project[]>([])
  const [videos, setVideos] = useState<Video[]>([])
  const [loading, setLoading] = useState(true)
  const [showNewProject, setShowNewProject] = useState(false)
  const [projectTitle, setProjectTitle] = useState('')
  const [selectedProject, setSelectedProject] = useState<string | null>(null)
  const [uploadingImage, setUploadingImage] = useState(false)

  useEffect(() => {
    if (!session) {
      router.push('/login')
      return
    }

    fetchProjects()
  }, [session, router])

  async function fetchProjects() {
    try {
      const response = await fetch('/api/projects')
      if (!response.ok) throw new Error('Failed to fetch')
      const data = await response.json()
      setProjects(data.projects)
      if (data.projects.length > 0) {
        setSelectedProject(data.projects[0].id)
        fetchVideos(data.projects[0].id)
      }
    } catch (error) {
      console.error('[v0] Fetch projects error:', error)
      toast.error('Failed to load projects')
    } finally {
      setLoading(false)
    }
  }

  async function fetchVideos(projectId: string) {
    try {
      const response = await fetch(`/api/videos?projectId=${projectId}`)
      if (response.ok) {
        const data = await response.json()
        setVideos(data.videos)
      }
    } catch (error) {
      console.error('[v0] Fetch videos error:', error)
    }
  }

  async function createProject() {
    if (!projectTitle.trim()) {
      toast.error('Enter a project title')
      return
    }

    try {
      const response = await fetch('/api/projects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: projectTitle }),
      })

      if (!response.ok) throw new Error('Failed to create')

      const data = await response.json()
      setProjects([...projects, data.project])
      setSelectedProject(data.project.id)
      setProjectTitle('')
      setShowNewProject(false)
      toast.success('Project created!')
    } catch (error) {
      console.error('[v0] Create project error:', error)
      toast.error('Failed to create project')
    }
  }

  async function handleImageSelect(url: string, file: File) {
    if (!selectedProject) {
      toast.error('Select a project first')
      return
    }

    setUploadingImage(true)
    try {
      const response = await fetch('/api/videos', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          projectId: selectedProject,
          title: file.name.replace(/\.[^/.]+$/, ''),
          sourceImage: url,
        }),
      })

      if (!response.ok) throw new Error('Failed to create')

      const data = await response.json()
      setVideos([...videos, data.video])
      toast.success('Video created! Opening editor...')
      
      setTimeout(() => {
        router.push(`/editor/${data.video.id}`)
      }, 500)
    } catch (error) {
      console.error('[v0] Create video error:', error)
      toast.error('Failed to create video')
    } finally {
      setUploadingImage(false)
    }
  }

  async function deleteVideo(videoId: string) {
    if (!confirm('Delete this video?')) return

    try {
      const response = await fetch(`/api/videos/${videoId}`, { method: 'DELETE' })
      if (!response.ok) throw new Error('Delete failed')

      setVideos(videos.filter((v) => v.id !== videoId))
      toast.success('Video deleted')
    } catch (error) {
      console.error('[v0] Delete error:', error)
      toast.error('Failed to delete video')
    }
  }

  if (!session) return null

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <div className="bg-slate-800 border-b border-slate-700 p-6">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white">MangaMotion AI</h1>
            <p className="text-slate-400 mt-1">Welcome, {session.user.name || 'User'}</p>
          </div>

          <div className="flex items-center gap-4">
            <button className="p-2 hover:bg-slate-700 rounded-lg transition text-slate-400 hover:text-white">
              <Settings size={24} />
            </button>
            <button
              onClick={() => signOut()}
              className="flex items-center gap-2 bg-slate-700 hover:bg-slate-600 text-white px-4 py-2 rounded-lg transition"
            >
              <LogOut size={20} />
              Logout
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-slate-800 rounded-lg p-6 space-y-4">
              <button
                onClick={() => setShowNewProject(true)}
                className="w-full flex items-center justify-center gap-2 bg-purple-600 hover:bg-purple-700 text-white font-semibold py-2 rounded-lg transition"
              >
                <Plus size={20} />
                New Project
              </button>

              {showNewProject && (
                <div className="space-y-2">
                  <input
                    type="text"
                    value={projectTitle}
                    onChange={(e) => setProjectTitle(e.target.value)}
                    placeholder="Project name"
                    className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:border-purple-500"
                  />
                  <div className="flex gap-2">
                    <button
                      onClick={createProject}
                      className="flex-1 bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg transition text-sm"
                    >
                      Create
                    </button>
                    <button
                      onClick={() => {
                        setShowNewProject(false)
                        setProjectTitle('')
                      }}
                      className="flex-1 bg-slate-700 hover:bg-slate-600 text-white px-4 py-2 rounded-lg transition text-sm"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              )}

              <div className="space-y-2">
                <p className="text-xs font-semibold text-slate-400 uppercase">Projects</p>
                {projects.length === 0 ? (
                  <p className="text-sm text-slate-400">No projects yet</p>
                ) : (
                  projects.map((project) => (
                    <button
                      key={project.id}
                      onClick={() => {
                        setSelectedProject(project.id)
                        fetchVideos(project.id)
                      }}
                      className={`w-full text-left px-4 py-2 rounded-lg transition text-sm ${
                        selectedProject === project.id
                          ? 'bg-purple-600 text-white'
                          : 'bg-slate-700 hover:bg-slate-600 text-slate-300'
                      }`}
                    >
                      {project.title}
                    </button>
                  ))
                )}
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3 space-y-6">
            {/* Upload Section */}
            <div className="bg-slate-800 rounded-lg p-6">
              <h2 className="text-xl font-bold text-white mb-4">Create New Video</h2>
              <ImageUploader
                onImageSelect={handleImageSelect}
                disabled={!selectedProject || uploadingImage}
              />
            </div>

            {/* Videos Grid */}
            {videos.length > 0 && (
              <div>
                <h2 className="text-xl font-bold text-white mb-4">Videos in {projects.find(p => p.id === selectedProject)?.title}</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {videos.map((video) => (
                    <div key={video.id} className="bg-slate-800 rounded-lg overflow-hidden hover:ring-2 hover:ring-purple-500 transition">
                      <img
                        src={video.sourceImage}
                        alt={video.title}
                        className="w-full h-40 object-cover"
                      />
                      <div className="p-4">
                        <h3 className="font-semibold text-white truncate">{video.title}</h3>
                        <p className="text-sm text-slate-400 mb-3">
                          Status: <span className="capitalize">{video.status}</span>
                        </p>
                        <div className="flex gap-2">
                          <button
                            onClick={() => router.push(`/editor/${video.id}`)}
                            className="flex-1 flex items-center justify-center gap-2 bg-purple-600 hover:bg-purple-700 text-white py-2 rounded-lg transition text-sm"
                          >
                            <Play size={16} />
                            Edit
                          </button>
                          <button
                            onClick={() => deleteVideo(video.id)}
                            className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {videos.length === 0 && !loading && (
              <div className="bg-slate-800 rounded-lg p-12 text-center">
                <p className="text-slate-400">No videos yet. Upload an image to get started!</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
