import { NextResponse } from 'next/server'
import { auth } from '@/lib/auth'
import { db } from '@/lib/db'
import { voiceProfiles } from '@/lib/db/schema'
import { eq } from 'drizzle-orm'
import { createId } from '@paralleldrive/cuid2'
import { headers } from 'next/headers'

export async function GET() {
  try {
    const session = await auth.api.getSession({
      headers: await headers(),
    })
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const userProfiles = await db
      .select()
      .from(voiceProfiles)
      .where(eq(voiceProfiles.userId, session.user.id))

    return NextResponse.json({ profiles: userProfiles })
  } catch (error) {
    console.error('[v0] Get voice profiles error:', error)
    return NextResponse.json({ error: 'Failed to fetch voice profiles' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const session = await auth.api.getSession({
      headers: await headers(),
    })
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { name, voiceId, language, speed, pitch } = body

    if (!name || !voiceId) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }

    const newProfile = await db
      .insert(voiceProfiles)
      .values({
        id: createId(),
        userId: session.user.id,
        name,
        voiceId,
        language: language || 'en',
        speed: String(speed || 1),
        pitch: String(pitch || 0),
      })
      .returning()

    return NextResponse.json({ profile: newProfile[0] }, { status: 201 })
  } catch (error) {
    console.error('[v0] Create voice profile error:', error)
    return NextResponse.json({ error: 'Failed to create voice profile' }, { status: 500 })
  }
}
